﻿using Microsoft.AspNetCore.Mvc;
using ShipsAPI.Entities;
using ShipsAPI.Services.Passengers;
using ShipsAPI.Services.Ships;
using System.Security.Cryptography.X509Certificates;

namespace ShipsAPI.Controllers
{

    [ApiController]
    [Route("api/ship/{imo}/passenger")]
    public class PassengerController : ControllerBase
    {
        private readonly IPassengerService _passengerService;

        public PassengerController(IPassengerService passengerService)
        {
            _passengerService = passengerService;
        }

        [HttpPost()]
        public IActionResult AddNewPassenger([FromRoute] string imo, [FromBody] Passenger passenger)
        {
            _passengerService.AddNewPassenger(imo,passenger);

            return Ok();
        }

        [HttpPost("all")]
        public IActionResult AddNewPassengers([FromRoute] string imo, [FromBody] IEnumerable<Passenger> passenger)
        {
            _passengerService.AddNewPassengers(imo, passenger);
            return Ok();
        }

        [HttpDelete("{passengerId}")]
        public IActionResult DeletePassenger([FromRoute] string imo, [FromRoute] int passengerId)
        {
            _passengerService.DeletePassenger(imo, passengerId);
            return Ok();
        }
    }
}
