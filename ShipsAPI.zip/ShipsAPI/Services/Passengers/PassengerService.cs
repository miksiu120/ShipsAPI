﻿using ShipsAPI.Entities;
using ShipsAPI.Models.Ships;
using ShipsAPI.Repositories;

namespace ShipsAPI.Services.Passengers
{
    public interface IPassengerService
    {
        void AddNewPassenger(string imo, Passenger passenger);
        void AddNewPassengers(string imo, IEnumerable<Passenger> passengers);
        void UpdatePassenger(string imo, Passenger passenger);
        void DeletePassenger(string imo, int passengerId);
    }

    public class PassengerService:IPassengerService
    {
        private readonly IShipRepository _shipRepository;

        public PassengerService(IShipRepository shipRepository)
        {
            _shipRepository = shipRepository;
        }

        public void AddNewPassenger(string imo, Passenger passenger)
        {
            var ship = _shipRepository.GetShipByIMO(imo) as PassengerShip
                       ?? throw new Exception($"Ship with IMO {imo} does not exist or is not a passenger ship");

            ship.Passengers ??= new List<Passenger>();

            if (ship.Passengers.Any(p => p.Id == passenger.Id))
            {
                throw new Exception($"Passenger with ID {passenger.Id} is already on board");
            }

            ship.Passengers.Add(passenger);

            _shipRepository.UpdateShip(ship);
        }

        public void AddNewPassengers(string imo, IEnumerable<Passenger> passengers)
        {
            var ship = _shipRepository.GetShipByIMO(imo) as PassengerShip
                       ?? throw new Exception($"Ship with IMO {imo} does not exist or is not a passenger ship");

            ship.Passengers ??= new List<Passenger>();

            foreach (var passenger in passengers)
            {
                if (ship.Passengers.Any(p => p.Id == passenger.Id))
                {
                    throw new Exception($"Passenger with ID {passenger.Id} is already on board");
                }

                ship.Passengers.Add(passenger);
            }

            _shipRepository.UpdateShip(ship);
        }

        public void UpdatePassenger(string imo, Passenger passenger)
        {
            var ship = _shipRepository.GetShipByIMO(imo) as PassengerShip
                       ?? throw new Exception($"Ship with IMO {imo} does not exist or is not a passenger ship");

            var existingPassenger = ship.Passengers?.FirstOrDefault(p => p.Id == passenger.Id)
                                    ?? throw new Exception($"Passenger with ID {passenger.Id} is not on board");

            existingPassenger = passenger;

            _shipRepository.UpdateShip(ship);
        }

        public void DeletePassenger(string imo, int passengerId)
        {
            var ship = _shipRepository.GetShipByIMO(imo) as PassengerShip
                       ?? throw new Exception($"Ship with IMO {imo} does not exist or is not a passenger ship");

            if (ship.Passengers?.RemoveAll(p => p.Id == passengerId) == 0)
            {
                throw new Exception($"Passenger with ID {passengerId} not found on board");
            }

            _shipRepository.UpdateShip(ship);
        }
    }

}
