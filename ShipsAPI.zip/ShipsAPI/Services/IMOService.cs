﻿namespace ShipsAPI.Services
{
    public static class IMOService
    {
        public static bool IsCorrect(string imo)
        {
            if(string.IsNullOrEmpty(imo) || imo.Length != 7 || !imo.All(char.IsDigit)) 
                return false;

            
            int controlSum = 0;
            int multiply = 7;
            for (int i = 0; i < imo.Length; i++)
            {
                controlSum += (imo[i] - '0') * multiply;
                multiply++;

            }

            if (controlSum % 10 != (imo[6] - '0'))
            {
                return false;
            }

            return true;
        }
    }
}
