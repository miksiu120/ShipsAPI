﻿using ShipsAPI.Models.Ships;
using ShipsAPI.Repositories;

namespace ShipsAPI.Services.Ships
{

    public interface ITankerShipService
    {
        void FuelUpTank(string imo, double amount, int tankId);
        void EmptyTheTank(string imo, int tankId);
    }

    public class TankerShipService: ITankerShipService
    {
        private readonly IShipRepository _shipRepository;

        public TankerShipService(IShipRepository shipRepository)
        {
            _shipRepository = shipRepository;
        }

        public void FuelUpTank(string imo, double amount, int tankId)
        {

            if (amount < 0)
            {
                throw new Exception($"You cannot fuelup tank with negative amount of fuel");
            }

            var existingShip = _shipRepository.GetShipByIMO(imo) as TankerShip;

            if (existingShip is null)
            {
                throw new Exception($"Ship with IMO: {imo} does not exist and cannot be fueled up");
            }

            if (existingShip.ShipType != ShipType.Tanker)
            {
                throw new Exception($"Only tankers can be fueledUp");
            }

            var tank = existingShip.Tanks?.FirstOrDefault(t => t.Id == tankId);

            if (tank is null)
            {
                throw new Exception($"Tank with ID: {tankId} does not exist on the ship");
            }

            if (tank.CurrentAmountInLitres + amount > tank.CapacityInLitres)
            {
                throw new Exception($"Tank with ID: {tank.Id} has {tank.CapacityInLitres} capacity. Trying to add overflow amount.");
            }

            tank.CurrentAmountInLitres += amount;

            _shipRepository.UpdateShip(existingShip);
        }

        public void EmptyTheTank(string imo, int tankId)
        {
            var existingShip = _shipRepository.GetShipByIMO(imo) as TankerShip;

            if (existingShip is null)
            {
                throw new Exception($"Ship with IMO: {imo} does not exist and cannot be fueled up");
            }

            var tank = existingShip.Tanks?.FirstOrDefault(t => t.Id == tankId);

            if (tank is null)
            {
                throw new Exception($"Tank with ID: {tankId} does not exist on the ship");
            }
            tank.CurrentAmountInLitres = 0;

            _shipRepository.UpdateShip(existingShip);
        }
    }
}
