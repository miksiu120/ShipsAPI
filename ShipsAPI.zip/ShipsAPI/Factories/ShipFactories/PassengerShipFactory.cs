﻿using ShipsAPI.Entities;
using ShipsAPI.Models.Ships;

namespace ShipsAPI.Factories.ShipFactories
{

    public class PassengerShipFactory : IShipFactory<NewPassengerShipDto>
    {
        public Ship CreateShip(NewPassengerShipDto dto)
        {
            return new PassengerShip
            {
                IMO = dto.IMO,
                Name = dto.Name,
                Length = dto.Length,
                Width = dto.Width,
                ShipType = dto.ShipType,
                Passengers = dto.Passengers
            };
        }
    }
}
