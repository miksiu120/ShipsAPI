using ShipsAPI.Factories.ShipFactories;
using ShipsAPI.Models.Ships;
using ShipsAPI.Repositories;
using ShipsAPI.Services.Passengers;
using ShipsAPI.Services.Ships;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring OpenAPI at https://aka.ms/aspnet/openapi
builder.Services.AddOpenApi();

builder.Services.AddScoped<IShipRepository,ShipRepository>();

builder.Services.AddScoped<IShipService, ShipService>();
builder.Services.AddScoped<ITankerShipService, TankerShipService>();
builder.Services.AddScoped<IPassengerService,PassengerService>();

builder.Services.AddTransient<IShipFactory<NewPassengerShipDto>, PassengerShipFactory>();
builder.Services.AddTransient<IShipFactory<NewTankerShipDto>, TankerShipFactory>();
builder.Services.AddTransient<IShipFactoryProvider, ShipFactoryProvider>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
