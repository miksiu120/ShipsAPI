﻿namespace ShipsAPI.Entities
{
    public class Passenger
    {
        public required int Id { get; set; }
        public required string Name { get; set; }
        public required string Surname { get; set; }
    }
}
