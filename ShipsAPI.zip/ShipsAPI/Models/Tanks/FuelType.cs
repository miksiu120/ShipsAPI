﻿namespace ShipsAPI.Models.Tanks
{
    public enum FuelType
    {
        Diesel,
        HeavyFuel
    }
}
