﻿namespace ShipsAPI.Models.Tanks
{
    public class Tank
    {
        public int Id { get; set; }
        public double CapacityInLitres { get; set; }
        public FuelType Fuel { get; set; }
        public double CurrentAmountInLitres { get; set; }
    }
}
