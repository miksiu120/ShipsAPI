﻿using ShipsAPI.Entities;
using ShipsAPI.Models.Tanks;

namespace ShipsAPI.Models.Ships
{
    public class TankerShip:Ship
    {
        public List<Tank>? Tanks { get; set; }
    }
}
