﻿using ShipsAPI.Entities;

namespace ShipsAPI.Models.Ships
{
    public class PassengerShip : Ship
    {
        public List<Passenger>? Passengers { get; set; }
    }
}
