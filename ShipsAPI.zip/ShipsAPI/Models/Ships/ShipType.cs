﻿namespace ShipsAPI.Models.Ships
{
    public enum ShipType
    {
        Tanker,
        Passenger
    }
}
 