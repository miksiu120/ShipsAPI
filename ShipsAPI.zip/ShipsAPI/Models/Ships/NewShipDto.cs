﻿using ShipsAPI.Entities;
using ShipsAPI.Models.Tanks;

namespace ShipsAPI.Models.Ships
{
    public abstract class NewShipDtoBase
    {
        public required string IMO { get; set; }
        public required string Name { get; set; }
        public required double Width { get; set; }
        public required double Length { get; set; }
        public abstract ShipType ShipType { get;  }
    }

    public class NewPassengerShipDto : NewShipDtoBase
    {
        public override ShipType ShipType => ShipType.Passenger;
        public required List<Passenger> Passengers { get; set; }
    }

    public class NewTankerShipDto : NewShipDtoBase
    {
        public override ShipType ShipType => ShipType.Tanker;
        public required List<Tank> Tanks { get; set; }
    }
}
